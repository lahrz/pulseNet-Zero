#!/usr/bin/env bash
set -e

echo "============================================================"
echo "  PULSENET-ZERO // MSME Automated Optical Inspection (AOI)  "
echo "  Sub-15ms Edge Vision Engine & Factory Telemetry Console    "
echo "============================================================"
echo ""

if ! command -v node >/dev/null 2>&1; then
    echo "[ERROR] Node.js is required. Install from https://nodejs.org"
    exit 1
fi

if [ ! -d "node_modules" ]; then
    echo "[SETUP] Installing dependencies..."
    npm install --legacy-peer-deps
fi

if [ ! -d "dist" ]; then
    echo "[BUILD] Building production assets..."
    npm run build
fi

echo "[STATUS] Launching PulseNet-Zero workstation..."
echo "[URL] http://localhost:3000"

if command -v xdg-open >/dev/null 2>&1; then
    xdg-open "http://localhost:3000" &
elif command -v open >/dev/null 2>&1; then
    open "http://localhost:3000" &
fi

npm start
