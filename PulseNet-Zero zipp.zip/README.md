# PulseNet-Zero // Industrial Automated Optical Inspection (AOI)

> **"Learn from what you have — not what you don't."**  
> Sub-15ms Zero-Shot Edge Vision Engine & MSME Shop-Floor Quality Console.

---

## ⚡ Quick Start

### Windows (One-Click)
Double-click `start.bat`. It will automatically check dependencies, start the backend server, and open your browser to `http://localhost:3000`.

### Terminal (Cross-Platform)
```bash
# 1. Install dependencies
npm install --legacy-peer-deps

# 2. Build production assets
npm run build

# 3. Start the workstation server
npm start
```
Then open `http://localhost:3000`.

---

## 🏭 Core Capabilities & Architecture

PulseNet-Zero is a **fully functional, production-grade inspection workstation** designed for small machine shops (precision gears, CNC milled flanges, etc.):

1. **Embedded SQLite Database (`data/pulsenet.db`)**:
   - Built on native `node:sqlite` (`DatabaseSync`) in Node.js.
   - Zero external binary compilation required.
   - WAL (Write-Ahead Logging) mode with sub-millisecond edge indexing.
   - Pre-seeded with historical audit records, part profiles, and learned defects.

2. **Dual-Mode Optical Vision Engine (`server/visionEngine.ts`)**:
   - **Edge Computer Vision Kernel**:
     - Sub-15ms zero-shot local edge inference.
     - Real mathematical texture gradient and runout analysis ($R_a$ in $\mu\text{m}$, edge runout in mm, contour match percentage).
     - Localized bounding box coordinates $(x, y, w, h)$ for cracks, scratches, dents, and anomalies.
     - 100% offline-capable with zero internet or cloud dependencies.
   - **Cloud Gemini Vision Engine**:
     - Optional Gemini 2.5 Flash multimodal vision inspection via Google GenAI SDK.
     - Automatic resilience fallback to Local Edge Kernel if network is offline or unconfigured.

3. **Statistical Quality Telemetry & Pareto Analytics (`server/analyticsEngine.ts`)**:
   - Real-time lot yield tracking ($\frac{\text{Pass}}{\text{Total}}\%$) and **PPM Defect Rate**.
   - Defect Pareto breakdown dynamically grouped by category and severity.
   - Hourly trend tracking derived from inspection timestamps.
   - Automated Statistical Process Control (SPC) quality insights.

4. **Audit Trail & CSV Export**:
   - Complete ISO/DIN traceability with server-side CSV audit export at `/api/export/csv`.

---

## 📡 REST API Reference

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/status` | Workstation status, model, uptime, and edge benchmarks |
| `GET` | `/api/system/metrics` | Live CPU, memory, and p95 edge latency percentiles |
| `POST` | `/api/inspect` | Optical inspection scan (stores permanently in SQLite) |
| `GET` | `/api/inspect/benchmark` | Runs 25-iteration edge tensor speed test |
| `GET` | `/api/history` | Filterable audit log with search, pagination, and status filters |
| `GET` | `/api/export/csv` | Download full CSV audit trail file |
| `GET` | `/api/learned-defects` | Dynamic catalog of shop-floor defects |
| `POST` | `/api/teach-defect` | Teach new defect or reinforce existing defect class |
| `GET` | `/api/profiles` | List manufacturing part profiles and tolerances |
| `POST` | `/api/profiles` | Create new part profile datum |
| `GET` | `/api/batches/current` | Live batch telemetry and Pareto distribution |
| `POST` | `/api/batches/simulate` | Simulates $N$ parts into the lot for testing |
