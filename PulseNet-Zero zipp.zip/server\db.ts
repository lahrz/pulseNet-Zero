import { DatabaseSync } from 'node:sqlite';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import {
  InspectionRecord,
  LearnedDefectItem,
  PartProfile,
  GoldenSample,
  BatchSummary,
} from './types.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Ensure data directory exists
const DATA_DIR = path.resolve(__dirname, '..', 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const DB_PATH = path.join(DATA_DIR, 'pulsenet.db');
export const db = new DatabaseSync(DB_PATH);

// Configure WAL mode & pragmas for maximum edge performance
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA synchronous = NORMAL;');
db.exec('PRAGMA foreign_keys = ON;');

// Initialize Tables
export function initDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS part_profiles (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      sku TEXT NOT NULL UNIQUE,
      category TEXT NOT NULL,
      tolerance TEXT NOT NULL,
      golden_samples_count INTEGER NOT NULL DEFAULT 8,
      features_learned_json TEXT NOT NULL,
      specs_json TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS golden_samples (
      id TEXT PRIMARY KEY,
      profile_id TEXT NOT NULL,
      label TEXT NOT NULL,
      angle TEXT NOT NULL,
      uri TEXT NOT NULL,
      added_at TEXT NOT NULL,
      FOREIGN KEY (profile_id) REFERENCES part_profiles(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS learned_defects (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL UNIQUE,
      category TEXT NOT NULL,
      added_at TEXT NOT NULL,
      samples_count INTEGER NOT NULL DEFAULT 1,
      severity TEXT NOT NULL DEFAULT 'MAJOR',
      color TEXT NOT NULL DEFAULT '#00f0ff'
    );

    CREATE TABLE IF NOT EXISTS batches (
      id TEXT PRIMARY KEY,
      batch_number TEXT NOT NULL UNIQUE,
      start_time TEXT NOT NULL,
      end_time TEXT,
      status TEXT NOT NULL DEFAULT 'ACTIVE',
      notes TEXT
    );

    CREATE TABLE IF NOT EXISTS inspections (
      id TEXT PRIMARY KEY,
      batch_id TEXT,
      timestamp TEXT NOT NULL,
      part_id TEXT NOT NULL,
      part_profile TEXT NOT NULL,
      status TEXT NOT NULL,
      defect_type TEXT,
      confidence REAL NOT NULL,
      anomaly_score REAL NOT NULL,
      location_json TEXT,
      processing_time_ms REAL NOT NULL,
      processing_engine TEXT NOT NULL,
      observations_json TEXT NOT NULL,
      metrics_json TEXT NOT NULL,
      image_url TEXT,
      notes TEXT
    );

    CREATE INDEX IF NOT EXISTS idx_inspections_timestamp ON inspections(timestamp DESC);
    CREATE INDEX IF NOT EXISTS idx_inspections_status ON inspections(status);
    CREATE INDEX IF NOT EXISTS idx_inspections_profile ON inspections(part_profile);
    CREATE INDEX IF NOT EXISTS idx_inspections_batch ON inspections(batch_id);

    CREATE TABLE IF NOT EXISTS system_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp TEXT NOT NULL,
      level TEXT NOT NULL,
      message TEXT NOT NULL,
      details_json TEXT
    );
  `);

  seedInitialData();
}

function seedInitialData() {
  // 1. Seed Part Profiles
  const profileCountStmt = db.prepare('SELECT COUNT(*) as cnt FROM part_profiles');
  const profileCountResult = profileCountStmt.get() as { cnt: number };
  if (profileCountResult.cnt === 0) {
    const insertProfile = db.prepare(`
      INSERT INTO part_profiles (id, name, sku, category, tolerance, golden_samples_count, features_learned_json, specs_json, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    insertProfile.run(
      'profile-gear',
      'Precision Gear',
      'PNZ-GEAR-M12',
      'Powertrain Gearing',
      '±0.008 mm (DIN 3962 Class 6)',
      8,
      JSON.stringify(['Involute Flank Profile', 'Root Radius Geometry', 'Keyway Concentricity', 'Specular Uniformity', 'Pitch Circle Runout']),
      JSON.stringify({
        outerDiameter: '80.0 mm',
        boreDiameter: '28.0 mm',
        thickness: '18.0 mm',
        material: 'AISI 8620 Case-Hardened Steel',
      }),
      new Date().toISOString()
    );

    insertProfile.run(
      'profile-flange',
      'CNC Milled Flange',
      'PNZ-FLG-44',
      'Pressure Vessels',
      '±0.012 mm (ANSI B16.5)',
      8,
      JSON.stringify(['Bolt Hole Spacing', 'Raised Face Planarity', 'Machined Toolpath Grooves', 'Inner Bore Chamfer']),
      JSON.stringify({
        outerDiameter: '120.0 mm',
        boreDiameter: '45.0 mm',
        thickness: '14.0 mm',
        material: '316L Stainless Steel',
      }),
      new Date().toISOString()
    );
  }

  // 2. Seed Learned Defects
  const defectCountStmt = db.prepare('SELECT COUNT(*) as cnt FROM learned_defects');
  const defectCountResult = defectCountStmt.get() as { cnt: number };
  if (defectCountResult.cnt === 0) {
    const insertDefect = db.prepare(`
      INSERT INTO learned_defects (id, name, category, added_at, samples_count, severity, color)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);

    insertDefect.run('def-1', 'Micro-Crack', 'Structural Flaw', '2026-10-18T19:30:00Z', 4, 'CRITICAL', '#ef4444');
    insertDefect.run('def-2', 'Surface Burr', 'Machining Residue', '2026-10-18T20:15:00Z', 6, 'MAJOR', '#f97316');
    insertDefect.run('def-3', 'Tooth Chipping', 'Form Irregularity', '2026-10-18T21:40:00Z', 3, 'CRITICAL', '#e11d48');
    insertDefect.run('def-4', 'Surface Scratch', 'Surface Scuff', '2026-10-19T08:10:00Z', 5, 'MAJOR', '#f43f5e');
    insertDefect.run('def-5', 'Radial Dent', 'Impact Depression', '2026-10-19T09:45:00Z', 2, 'MAJOR', '#fb923c');
  }

  // 3. Seed Batch
  const batchCountStmt = db.prepare('SELECT COUNT(*) as cnt FROM batches');
  const batchCountResult = batchCountStmt.get() as { cnt: number };
  if (batchCountResult.cnt === 0) {
    const insertBatch = db.prepare(`
      INSERT INTO batches (id, batch_number, start_time, status, notes)
      VALUES (?, ?, ?, ?, ?)
    `);
    insertBatch.run('batch-42', '#PNZ-042', '2026-10-18T08:00:00Z', 'ACTIVE', 'Production lot: 100 Precision Gears M12');
  }

  // 4. Seed Historical Inspection Records
  const inspectCountStmt = db.prepare('SELECT COUNT(*) as cnt FROM inspections');
  const inspectCountResult = inspectCountStmt.get() as { cnt: number };
  if (inspectCountResult.cnt === 0) {
    const insertInspect = db.prepare(`
      INSERT INTO inspections (
        id, batch_id, timestamp, part_id, part_profile, status, defect_type,
        confidence, anomaly_score, location_json, processing_time_ms,
        processing_engine, observations_json, metrics_json, notes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    // Add baseline realistic audit trail records
    insertInspect.run(
      'PNZ-REC-098',
      'batch-42',
      '2026-10-18T23:18:12Z',
      'PART-098',
      'Precision Gear (PNZ-GEAR-M12)',
      'PASS',
      null,
      0.984,
      0.03,
      null,
      14.2,
      'PulseNet Edge Kernel (WebAssembly/Local SIMD)',
      JSON.stringify(['Flank concentricity nominal', 'Zero burr threshold met', 'Ra 0.78μm']),
      JSON.stringify({ surfaceRoughnessRa: '0.78 μm', edgeRunout: '0.005 mm', contourMatch: '99.2%' }),
      'Nominal QA inspection pass'
    );

    insertInspect.run(
      'PNZ-REC-099',
      'batch-42',
      '2026-10-18T23:22:45Z',
      'PART-099',
      'Precision Gear (PNZ-GEAR-M12)',
      'DEFECT',
      'Surface Scratch',
      0.942,
      0.79,
      JSON.stringify({ x: 38, y: 44, width: 24, height: 18 }),
      12.8,
      'PulseNet Edge Kernel (WebAssembly/Local SIMD)',
      JSON.stringify(['Linear scoring on flank tooth 4', 'Specular variance > 40%']),
      JSON.stringify({ surfaceRoughnessRa: '1.42 μm', edgeRunout: '0.038 mm', contourMatch: '87.4%' }),
      'Flank scratch flagged by vision sensor'
    );

    insertInspect.run(
      'PNZ-REC-100',
      'batch-42',
      '2026-10-18T23:25:30Z',
      'PART-100',
      'Precision Gear (PNZ-GEAR-M12)',
      'UNKNOWN',
      'Unclassified Anomaly',
      0.720,
      0.64,
      JSON.stringify({ x: 42, y: 55, width: 28, height: 25 }),
      15.1,
      'PulseNet Edge Kernel (WebAssembly/Local SIMD)',
      JSON.stringify(['Unfamiliar dark particulate deposit', 'Deviation 3.8σ from normal profile']),
      JSON.stringify({ surfaceRoughnessRa: '1.10 μm', edgeRunout: '0.018 mm', contourMatch: '91.0%' }),
      'Operator review requested'
    );
  }
}

// Data Access Helpers
export const dbService = {
  // Inspections
  saveInspection(record: InspectionRecord, batchId = 'batch-42'): void {
    const stmt = db.prepare(`
      INSERT INTO inspections (
        id, batch_id, timestamp, part_id, part_profile, status, defect_type,
        confidence, anomaly_score, location_json, processing_time_ms,
        processing_engine, observations_json, metrics_json, image_url, notes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run(
      record.id,
      batchId,
      record.timestamp,
      record.partId,
      record.partProfile,
      record.status,
      record.defectType,
      record.confidence,
      record.anomalyScore,
      record.location ? JSON.stringify(record.location) : null,
      record.processingTimeMs,
      record.processingEngine,
      JSON.stringify(record.observations),
      JSON.stringify(record.metrics),
      record.imageUrl || null,
      record.notes || null
    );
  },

  getInspections(params?: {
    status?: string;
    profile?: string;
    search?: string;
    limit?: number;
    offset?: number;
  }): { records: InspectionRecord[]; total: number } {
    const { status, profile, search, limit = 100, offset = 0 } = params || {};
    const conditions: string[] = [];
    const values: any[] = [];

    if (status && status !== 'ALL') {
      conditions.push('status = ?');
      values.push(status);
    }

    if (profile) {
      conditions.push('part_profile = ?');
      values.push(profile);
    }

    if (search && search.trim()) {
      conditions.push('(part_id LIKE ? OR part_profile LIKE ? OR defect_type LIKE ?)');
      const pattern = `%${search.trim()}%`;
      values.push(pattern, pattern, pattern);
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    const countStmt = db.prepare(`SELECT COUNT(*) as total FROM inspections ${whereClause}`);
    const countRow = countStmt.get(...values) as { total: number };

    const queryStmt = db.prepare(`
      SELECT * FROM inspections
      ${whereClause}
      ORDER BY timestamp DESC
      LIMIT ? OFFSET ?
    `);

    const rows = queryStmt.all(...values, limit, offset) as any[];

    const records: InspectionRecord[] = rows.map((r) => ({
      id: r.id,
      timestamp: r.timestamp,
      partId: r.part_id,
      partProfile: r.part_profile,
      status: r.status,
      defectType: r.defect_type,
      confidence: r.confidence,
      anomalyScore: r.anomaly_score,
      location: r.location_json ? JSON.parse(r.location_json) : null,
      processingTimeMs: r.processing_time_ms,
      processingEngine: r.processing_engine,
      observations: r.observations_json ? JSON.parse(r.observations_json) : [],
      metrics: r.metrics_json ? JSON.parse(r.metrics_json) : { surfaceRoughnessRa: '0.80 μm', edgeRunout: '0.008 mm', contourMatch: '98.5%' },
      imageUrl: r.image_url || undefined,
      notes: r.notes || undefined,
    }));

    return { records, total: countRow.total };
  },

  getInspectionById(id: string): InspectionRecord | null {
    const stmt = db.prepare('SELECT * FROM inspections WHERE id = ?');
    const r = stmt.get(id) as any;
    if (!r) return null;
    return {
      id: r.id,
      timestamp: r.timestamp,
      partId: r.part_id,
      partProfile: r.part_profile,
      status: r.status,
      defectType: r.defect_type,
      confidence: r.confidence,
      anomalyScore: r.anomaly_score,
      location: r.location_json ? JSON.parse(r.location_json) : null,
      processingTimeMs: r.processing_time_ms,
      processingEngine: r.processing_engine,
      observations: r.observations_json ? JSON.parse(r.observations_json) : [],
      metrics: r.metrics_json ? JSON.parse(r.metrics_json) : { surfaceRoughnessRa: '0.80 μm', edgeRunout: '0.008 mm', contourMatch: '98.5%' },
      imageUrl: r.image_url || undefined,
      notes: r.notes || undefined,
    };
  },

  deleteInspection(id: string): boolean {
    const stmt = db.prepare('DELETE FROM inspections WHERE id = ?');
    stmt.run(id);
    return true;
  },

  clearInspections(): void {
    db.exec('DELETE FROM inspections');
  },

  // Learned Defects
  getLearnedDefects(): LearnedDefectItem[] {
    const stmt = db.prepare('SELECT * FROM learned_defects ORDER BY added_at DESC');
    const rows = stmt.all() as any[];
    return rows.map((r) => ({
      id: r.id,
      name: r.name,
      category: r.category,
      addedAt: r.added_at,
      samplesCount: r.samples_count,
      severity: r.severity,
      color: r.color,
    }));
  },

  upsertLearnedDefect(defectName: string, category = 'Surface Anomaly', severity: 'CRITICAL' | 'MAJOR' | 'MINOR' = 'MAJOR'): LearnedDefectItem {
    const findStmt = db.prepare('SELECT * FROM learned_defects WHERE LOWER(name) = LOWER(?)');
    const existing = findStmt.get(defectName) as any;

    if (existing) {
      const updateStmt = db.prepare('UPDATE learned_defects SET samples_count = samples_count + 1 WHERE id = ?');
      updateStmt.run(existing.id);
      return {
        id: existing.id,
        name: existing.name,
        category: existing.category,
        addedAt: existing.added_at,
        samplesCount: existing.samples_count + 1,
        severity: existing.severity,
        color: existing.color,
      };
    }

    const newId = `def-${Date.now()}`;
    const addedAt = new Date().toISOString();
    const color = severity === 'CRITICAL' ? '#ef4444' : severity === 'MAJOR' ? '#f97316' : '#00f0ff';

    const insertStmt = db.prepare(`
      INSERT INTO learned_defects (id, name, category, added_at, samples_count, severity, color)
      VALUES (?, ?, ?, ?, 1, ?, ?)
    `);
    insertStmt.run(newId, defectName, category, addedAt, severity, color);

    return {
      id: newId,
      name: defectName,
      category,
      addedAt,
      samplesCount: 1,
      severity,
      color,
    };
  },

  deleteLearnedDefect(id: string): boolean {
    const stmt = db.prepare('DELETE FROM learned_defects WHERE id = ?');
    stmt.run(id);
    return true;
  },

  // Part Profiles
  getPartProfiles(): PartProfile[] {
    const stmt = db.prepare('SELECT * FROM part_profiles ORDER BY name ASC');
    const rows = stmt.all() as any[];
    return rows.map((r) => ({
      id: r.id,
      name: r.name,
      sku: r.sku,
      category: r.category,
      tolerance: r.tolerance,
      goldenSamplesCount: r.golden_samples_count,
      featuresLearned: JSON.parse(r.features_learned_json || '[]'),
      specs: JSON.parse(r.specs_json || '{}'),
      createdAt: r.created_at,
    }));
  },

  createPartProfile(profile: Omit<PartProfile, 'id'>): PartProfile {
    const id = `profile-${Date.now()}`;
    const createdAt = new Date().toISOString();
    const stmt = db.prepare(`
      INSERT INTO part_profiles (id, name, sku, category, tolerance, golden_samples_count, features_learned_json, specs_json, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run(
      id,
      profile.name,
      profile.sku,
      profile.category,
      profile.tolerance,
      profile.goldenSamplesCount || 8,
      JSON.stringify(profile.featuresLearned || []),
      JSON.stringify(profile.specs || {}),
      createdAt
    );

    return {
      id,
      ...profile,
      createdAt,
    };
  },

  deletePartProfile(id: string): boolean {
    const stmt = db.prepare('DELETE FROM part_profiles WHERE id = ?');
    stmt.run(id);
    return true;
  },

  // Golden Samples
  getGoldenSamples(profileId: string): GoldenSample[] {
    const stmt = db.prepare('SELECT * FROM golden_samples WHERE profile_id = ? ORDER BY added_at ASC');
    const rows = stmt.all(profileId) as any[];
    return rows.map((r) => ({
      id: r.id,
      profileId: r.profile_id,
      label: r.label,
      angle: r.angle,
      uri: r.uri,
      addedAt: r.added_at,
    }));
  },

  addGoldenSample(profileId: string, sample: Omit<GoldenSample, 'id' | 'profileId' | 'addedAt'>): GoldenSample {
    const id = `gold-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const addedAt = new Date().toISOString();
    const stmt = db.prepare(`
      INSERT INTO golden_samples (id, profile_id, label, angle, uri, added_at)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    stmt.run(id, profileId, sample.label, sample.angle, sample.uri, addedAt);

    // Increment profile golden sample count
    const updateStmt = db.prepare('UPDATE part_profiles SET golden_samples_count = golden_samples_count + 1 WHERE id = ?');
    updateStmt.run(profileId);

    return {
      id,
      profileId,
      label: sample.label,
      angle: sample.angle,
      uri: sample.uri,
      addedAt,
    };
  },

  // Batches
  getActiveBatch(): { id: string; batchNumber: string; startTime: string } {
    const stmt = db.prepare("SELECT * FROM batches WHERE status = 'ACTIVE' ORDER BY start_time DESC LIMIT 1");
    const row = stmt.get() as any;
    if (row) {
      return { id: row.id, batchNumber: row.batch_number, startTime: row.start_time };
    }
    const newId = `batch-${Date.now()}`;
    const batchNum = `#PNZ-${Math.floor(100 + Math.random() * 900)}`;
    const startTime = new Date().toISOString();
    const insertStmt = db.prepare("INSERT INTO batches (id, batch_number, start_time, status) VALUES (?, ?, ?, 'ACTIVE')");
    insertStmt.run(newId, batchNum, startTime);
    return { id: newId, batchNumber: batchNum, startTime };
  },

  createNewBatch(batchNumber?: string, notes?: string): { id: string; batchNumber: string; startTime: string } {
    // Mark prior active batches closed
    db.exec("UPDATE batches SET status = 'COMPLETED', end_time = CURRENT_TIMESTAMP WHERE status = 'ACTIVE'");

    const id = `batch-${Date.now()}`;
    const num = batchNumber || `#PNZ-${Math.floor(100 + Math.random() * 900)}`;
    const startTime = new Date().toISOString();
    const stmt = db.prepare("INSERT INTO batches (id, batch_number, start_time, status, notes) VALUES (?, ?, ?, 'ACTIVE', ?)");
    stmt.run(id, num, startTime, notes || null);
    return { id, batchNumber: num, startTime };
  },
};

// Initialize database schema on load
initDatabase();
