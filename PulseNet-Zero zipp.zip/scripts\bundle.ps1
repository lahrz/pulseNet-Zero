$ErrorActionPreference = "Stop"

$desktop1 = "C:\Users\steve\OneDrive\Desktop"
$desktop2 = "C:\Users\steve\Desktop"

$zip1 = Join-Path $desktop1 "PulseNet-Zero.zip"
$zip2 = Join-Path $desktop2 "PulseNet-Zero.zip"

if (Test-Path $zip1) {
    Remove-Item -Force $zip1
}
if (Test-Path $zip2) {
    Remove-Item -Force $zip2
}

$items = @(
    "dist",
    "src",
    "server",
    "data",
    "public",
    "scripts",
    "server.ts",
    "index.html",
    "package.json",
    "package-lock.json",
    "bun.lock",
    "tsconfig.json",
    "vite.config.ts",
    "metadata.json",
    ".env",
    ".env.example",
    ".gitignore",
    "start.bat",
    "start.sh",
    "README.md"
)

Write-Host "Creating zip package at: $zip1"
Compress-Archive -Path $items -DestinationPath $zip1 -CompressionLevel Optimal

if (Test-Path $desktop2) {
    Copy-Item -Path $zip1 -Destination $zip2 -Force
    Write-Host "Mirrored to: $zip2"
}

$fileInfo = Get-Item $zip1
Write-Host "SUCCESS! Zip file created. Size: $([math]::Round($fileInfo.Length / 1MB, 2)) MB"
