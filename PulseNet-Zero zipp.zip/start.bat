@echo off
setlocal
title PULSENET-ZERO - Industrial AOI Workstation

echo ============================================================
echo   PULSENET-ZERO // MSME Automated Optical Inspection (AOI)
echo   Sub-15ms Edge Vision Engine & Factory Telemetry Console
echo ============================================================
echo.

:: Check Node.js
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not found on PATH.
    echo Please install Node.js v18 or higher from https://nodejs.org
    echo.
    pause
    exit /b 1
)

:: Check if node_modules exists, install if needed
if not exist node_modules (
    echo [SETUP] Installing local workstation dependencies...
    call npm install --legacy-peer-deps
    if %errorlevel% neq 0 (
        echo [ERROR] Failed to install dependencies.
        pause
        exit /b 1
    )
)

:: Check if dist exists, build if needed
if not exist dist (
    echo [BUILD] Building production assets...
    call npm run build
)

echo.
echo [STATUS] Starting PulseNet-Zero Edge Inspection Server...
echo [CONSOLE] Opening workstation in browser at http://localhost:3000
echo.

start "" "http://localhost:3000"
call npm start
pause
